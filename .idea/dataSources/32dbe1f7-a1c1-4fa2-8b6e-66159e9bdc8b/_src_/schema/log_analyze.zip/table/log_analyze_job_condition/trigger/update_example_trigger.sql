CREATE TRIGGER `update_example_trigger`
BEFORE UPDATE ON `log_analyze_job_condition`
FOR EACH ROW
  SET NEW.`updateDate` = NOW()